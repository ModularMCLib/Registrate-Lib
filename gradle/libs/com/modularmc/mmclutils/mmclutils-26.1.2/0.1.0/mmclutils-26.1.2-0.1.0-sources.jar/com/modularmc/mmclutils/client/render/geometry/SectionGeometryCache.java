package com.modularmc.mmclutils.client.render.geometry;

import com.modularmc.mmclutils.api.shape.VoxelShapeCache;
import com.modularmc.mmclutils.client.render.geometry.SectionGeometryCapture.Geometry;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;

import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import org.jspecify.annotations.Nullable;

import java.util.function.LongConsumer;

/** 在客户端世界线程维护有界的区段采集缓存。采集模式变化时会替换同一区段的旧数据。 */
public final class SectionGeometryCache {

    private final ClientLevel level;
    private final int capacity;
    private final VoxelShapeCache shapes = new VoxelShapeCache();
    private final Long2ObjectLinkedOpenHashMap<Entry> sections = new Long2ObjectLinkedOpenHashMap<>();

    /** 为指定客户端世界创建一个有界缓存，容量按区段计且须为正数。 */
    public SectionGeometryCache(ClientLevel level, int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("区段缓存容量必须为正数");
        this.level = level;
        this.capacity = capacity;
    }

    /** 取得匹配模式且采集完成的数据，并更新该区段的访问顺序。未命中时返回空值。 */
    public @Nullable Geometry get(long section, int modes) {
        Entry entry = sections.getAndMoveToLast(section);
        return entry != null && entry.modes == modes ? entry.geometry : null;
    }

    /** 推进采集至指定时限。采集完成时转交可在后台读取的数据。 */
    public @Nullable Geometry advance(long section, int modes, long deadline) {
        Entry entry = sections.getAndMoveToLast(section);
        if (entry == null || entry.modes != modes) {
            if (System.nanoTime() >= deadline) return null;
            entry = new Entry(section, modes);
            sections.putAndMoveToLast(section, entry);
            if (sections.size() > capacity) sections.removeFirst();
        }
        SectionGeometryCapture capture = entry.capture;
        if (capture != null) {
            entry.geometry = capture.advance(level, shapes, deadline);
            if (entry.geometry != null) entry.capture = null;
        }
        return entry.geometry;
    }

    /** 移除指定区段的缓存和未完成采集。已交付的后台任务由调用方取消。 */
    public void invalidate(long section) {
        sections.remove(section);
    }

    /** 方块变化后作废所有读取过该位置的区段。调用方可以同时取消相同键的后台任务。 */
    public void invalidateBlock(long position) {
        shapes.clear();
        forAffectedSections(position, this::invalidate);
    }

    /** 遍历采集边缘可能包含该方块的区段。入参为方块打包坐标，回调接收原版区段打包坐标。 */
    public static void forAffectedSections(long position, LongConsumer action) {
        int x = BlockPos.getX(position), y = BlockPos.getY(position), z = BlockPos.getZ(position);
        for (int sx = (x - 1) >> 4; sx <= ((x + 1) >> 4); sx++) {
            for (int sy = (y - 1) >> 4; sy <= ((y + 1) >> 4); sy++) {
                for (int sz = (z - 1) >> 4; sz <= ((z + 1) >> 4); sz++) {
                    action.accept(SectionPos.asLong(sx, sy, sz));
                }
            }
        }
    }

    /** 区块加载、替换或移除时，作废本列及采集边界与其相交的区段。 */
    public void invalidateChunk(int x, int z) {
        var iterator = sections.keySet().iterator();
        while (iterator.hasNext()) {
            long section = iterator.nextLong();
            if (Math.abs(SectionPos.x(section) - x) <= 1 && Math.abs(SectionPos.z(section) - z) <= 1) iterator.remove();
        }
    }

    /** 世界或资源版本结束时释放全部采集状态。 */
    public void clear() {
        sections.clear();
        shapes.clear();
    }

    private static final class Entry {

        private final int modes;
        private @Nullable SectionGeometryCapture capture;
        private @Nullable Geometry geometry;

        private Entry(long section, int modes) {
            this.modes = modes;
            capture = new SectionGeometryCapture(section, modes);
        }
    }
}

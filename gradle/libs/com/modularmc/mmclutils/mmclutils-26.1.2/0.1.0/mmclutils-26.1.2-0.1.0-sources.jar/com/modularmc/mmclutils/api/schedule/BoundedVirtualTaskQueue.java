package com.modularmc.mmclutils.api.schedule;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.jspecify.annotations.Nullable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * 由所属线程提交、轮询和取消虚拟线程任务。结果队列有容量限制，计算线程只使用 Work 上下文。
 * 结果发出后归队列所有，轮询交付后由调用方释放。
 * 作废结果可能在计算线程或所属线程释放。释放动作须支持并发调用，并可脱离 GPU 上下文执行。
 *
 * @param <T> 从计算线程交付的结果值类型
 */
public final class BoundedVirtualTaskQueue<T> implements AutoCloseable {
    private final int parallelism;
    private final Consumer<T> release;
    private final ExecutorService executor;
    private final Semaphore workers;
    private final Semaphore resultSlots;
    private final Object handoff = new Object();
    private final ConcurrentLinkedQueue<Envelope<T>> results = new ConcurrentLinkedQueue<>();
    private final Long2ObjectOpenHashMap<Ticket> tasks = new Long2ObjectOpenHashMap<>();
    private long generation;
    private boolean closed;

    /**
     * 建立由调用线程维护的队列。
     *
     * @param threadPrefix   后台虚拟线程名称的前缀
     * @param parallelism    最多同时运行的计算数
     * @param resultCapacity 等待领取的结果数上限，包含终止结果
     * @param release        释放已作废结果的操作，须支持并发调用
     * @throws IllegalArgumentException 并发数或结果容量小于一
     */
    public BoundedVirtualTaskQueue(String threadPrefix, int parallelism, int resultCapacity, Consumer<T> release) {
        if (parallelism < 1 || resultCapacity < 1) throw new IllegalArgumentException("Task queue limits must be positive");
        this.parallelism = parallelism;
        this.release = release;
        workers = new Semaphore(parallelism);
        resultSlots = new Semaphore(resultCapacity);
        executor = Executors.newThreadPerTaskExecutor(Thread.ofVirtual().name(threadPrefix, 0).factory());
    }

    /**
     * 在所属线程查询提交容量。已完成的任务在终止结果被取走之前仍占用名额。
     */
    public boolean hasCapacity() {
        return !closed && tasks.size() < parallelism && workers.availablePermits() > 0;
    }

    /**
     * 查询指定原始类型键当前是否有任务。
     */
    public boolean contains(long key) {
        return tasks.containsKey(key);
    }

    /**
     * 在所属线程提交任务。每个键在终止结果被取走或任务取消后可复用。
     *
     * @param key         用于取消和关联结果的任务键
     * @param calculation 在后台线程执行的计算，可以通过工作上下文交付多条结果
     * @throws IllegalStateException 队列已关闭、没有空余任务名额或键已在使用
     */
    public void submit(long key, Consumer<Work<T>> calculation) {
        if (!hasCapacity() || tasks.containsKey(key) || !workers.tryAcquire()) throw new IllegalStateException("No task slot or duplicate task key: " + key);
        com.modularmc.mmclutils.api.schedule.BoundedVirtualTaskQueue.Ticket ticket = new Ticket(key, generation);
        com.modularmc.mmclutils.api.schedule.BoundedVirtualTaskQueue.Work<T> work = new Work<>(this, ticket);
        FutureTask<Boolean> future = new FutureTask<>(() -> {
            try {
                work.checkCancelled();
                calculation.accept(work);
                work.publish(null, null, true);
            } catch (RuntimeException | Error failure) {
                if (ticket.cancelled.get() || Thread.currentThread().isInterrupted()) ticket.cancelled.set(true);
                 else {
                    try {
                        work.publish(null, failure, true);
                    } catch (CancellationException stopped) {
                        ticket.cancelled.set(true);
                    }
                }
            }
            return Boolean.TRUE;
        });
        ticket.future = future;
        tasks.put(key, ticket);
        try {
            executor.execute(() -> {
                if (!ticket.started.compareAndSet(false, true)) return;
                try {
                    future.run();
                } finally {
                    workers.release();
                }
            });
        } catch (RuntimeException | Error failure) {
            tasks.remove(key);
            if (ticket.started.compareAndSet(false, true)) workers.release();
            throw failure;
        }
    }

    /**
     * 在所属线程轮询结果。普通结果一经返回，调用方负责释放其值。
     * 终止结果可以携带计算异常。已取消或作废的结果由队列释放。
     *
     * @return 下一条有效结果，暂时没有可领结果时返回空值
     */
    @Nullable
    public Result<T> poll() {
        Envelope<T> envelope;
        while ((envelope = results.poll()) != null) {
            resultSlots.release();
            Ticket ticket = envelope.ticket();
            Result<T> result = envelope.result();
            if (ticket.generation != generation || !tasks.containsKey(ticket.key) || tasks.get(ticket.key) != ticket) {
                if (result.value() != null) release.accept(result.value());
                continue;
            }
            if (result.terminal()) tasks.remove(ticket.key);
            return result;
        }
        it.unimi.dsi.fastutil.objects.ObjectIterator<it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry<com.modularmc.mmclutils.api.schedule.BoundedVirtualTaskQueue.Ticket>> iterator = tasks.long2ObjectEntrySet().fastIterator();
        while (iterator.hasNext()) {
            it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry<com.modularmc.mmclutils.api.schedule.BoundedVirtualTaskQueue.Ticket> entry = iterator.next();
            Ticket ticket = entry.getValue();
            if (ticket.cancelled.get() && ticket.future.isDone()) {
                long key = entry.getLongKey();
                iterator.remove();
                return new Result<>(key, null, new CancellationException("Worker stopped without publishing a result"), true);
            }
        }
        return null;
    }

    /**
     * 作废指定键并中断计算，立即释放尚未取走的结果。
     */
    public void cancel(long key) {
        if (!tasks.containsKey(key)) return;
        Ticket ticket = tasks.remove(key);
        synchronized (handoff) {
            ticket.cancelled.set(true);
            ticket.future.cancel(true);
            if (ticket.started.compareAndSet(false, true)) workers.release();
            results.removeIf(envelope -> {
                if (envelope.ticket() != ticket) return false;
                if (envelope.result().value() != null) release.accept(envelope.result().value());
                resultSlots.release();
                return true;
            });
        }
    }

    /**
     * 切换到下一代，取消全部任务并释放队列中的结果。
     */
    public void clear() {
        generation++;
        for (long key : tasks.keySet().toLongArray()) cancel(key);
    }

    /**
     * 关闭任务入口并中断计算线程。所属线程可立即返回。
     */
    @Override
    public void close() {
        clear();
        closed = true;
        executor.shutdownNow();
    }


    /**
     * 为后台计算提供取消状态和结果交付入口。工作上下文仅在本次计算期间使用。
     *
     * @param <T> 本次计算交付的结果值类型
     */
    public static final class Work<T> {
        private final BoundedVirtualTaskQueue<T> owner;
        private final Ticket ticket;
        /**
         * 与提交时相同的任务键。
         */
        private final long key;

        private Work(BoundedVirtualTaskQueue<T> owner, Ticket ticket) {
            this.owner = owner;
            this.ticket = ticket;
            key = ticket.key;
        }

        /**
         * 供计算循环检查取消或中断状态。
         */
        public boolean cancelled() {
            return ticket.cancelled.get() || Thread.currentThread().isInterrupted();
        }

        /**
         * 任务作废或计算线程中断时抛出取消异常。
         */
        public void checkCancelled() {
            if (cancelled()) throw new CancellationException();
        }

        /**
         * 交付一个非空结果，队列满时可中断地等待。结果一经传入即转交所有权。
         * 若交付因取消或其它异常失败，由该方法释放结果。
         *
         * @param value 由计算线程交出的结果值
         * @throws CancellationException 任务已取消或计算线程被中断
         */
        public void emit(T value) {
            try {
                publish(value, null, false);
            } catch (RuntimeException | Error failure) {
                owner.release.accept(value);
                throw failure;
            }
        }

        private void publish(@Nullable T value, @Nullable Throwable failure, boolean terminal) {
            checkCancelled();
            try {
                owner.resultSlots.acquire();
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw new CancellationException();
            }
            boolean transferred = false;
            try {
                synchronized (owner.handoff) {
                    checkCancelled();
                    owner.results.add(new Envelope<>(ticket, new Result<>(key, value, failure, terminal)));
                    transferred = true;
                }
            } finally {
                if (!transferred) owner.resultSlots.release();
            }
        }

        /**
         * 与提交时相同的任务键。
         */
        public long getKey() {
            return this.key;
        }
    }


    /**
     * 由所属线程接收的任务数据或终止通知。
     *
     * @param <T>      普通结果的值类型
     * @param key      提交任务时的键
     * @param value    普通结果的非空值，终止时为空
     * @param failure  终止原因，计算成功时为空
     * @param terminal 本条结果是否标记任务结束
     */
    public record Result<T>(long key, @Nullable T value, @Nullable Throwable failure, boolean terminal) {
    }


    private record Envelope<T>(Ticket ticket, Result<T> result) {
    }


    private static final class Ticket {
        private final long key;
        private final long generation;
        private final AtomicBoolean cancelled = new AtomicBoolean();
        private final AtomicBoolean started = new AtomicBoolean();
        private FutureTask<Boolean> future = new FutureTask<>(() -> Boolean.FALSE);

        private Ticket(long key, long generation) {
            this.key = key;
            this.generation = generation;
        }
    }
}

package com.modularmc.mmclutils.api.collection.map.enums;

import it.unimi.dsi.fastutil.objects.*;

import java.util.Arrays;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

/** 用枚举序号直接寻址的映射。按枚举常量的序号定位，缺失时返回配置的默认值。 迭代器可复用同一个可变条目。 */
public final class Enum2ObjectMap<K extends Enum<K>, V> extends AbstractReference2ReferenceMap<K, V> {

    private static final Object NULL = new Object();

    private final Class<K> keyType;
    private final K[] keys;
    private final Object[] vals;
    private int size;

    private final EntrySet entrySet = new EntrySet();
    private final ReferenceSet<K> keySet = new KeySet();
    private final ReferenceCollection<V> values = new Values();

    /** 为该枚举的全部常量分配槽位。 */
    public Enum2ObjectMap(Class<K> keyType) {
        this.keyType = keyType;
        this.keys = EnumMaps.universe(keyType);
        this.vals = new Object[keys.length];
    }

    /** 复制槽位中的条目，使用新映射的初始默认返回值。 */
    public Enum2ObjectMap(Enum2ObjectMap<K, V> map) {
        this.keyType = map.keyType;
        this.keys = map.keys;
        this.vals = map.vals.clone();
        this.size = map.size;
    }

    /** 返回此映射按序号直接寻址时使用的枚举类型。 */
    public Class<K> keyType() {
        return keyType;
    }

    @Override
    public V get(Object key) {
        if (!isValidKey(key)) return defRetValue;
        Object v = vals[((Enum<?>) key).ordinal()];
        return v == null ? defRetValue : unmaskNull(v);
    }

    @Override
    public V getOrDefault(Object key, V defaultValue) {
        if (!isValidKey(key)) return defaultValue;
        Object v = vals[((Enum<?>) key).ordinal()];
        return v == null ? defaultValue : unmaskNull(v);
    }

    @Override
    public V put(K key, V value) {
        int i = key.ordinal();
        Object old = vals[i];

        vals[i] = maskNull(value);
        if (old == null) size++;
        return old == null ? defRetValue : unmaskNull(old);
    }

    @Override
    public V remove(Object key) {
        if (!isValidKey(key)) return defRetValue;
        int i = ((Enum<?>) key).ordinal();
        Object old = vals[i];
        if (old == null) return defRetValue;
        vals[i] = null;
        size--;
        return unmaskNull(old);
    }

    @Override
    public boolean containsKey(Object key) {
        return isValidKey(key) && vals[((Enum<?>) key).ordinal()] != null;
    }

    @Override
    public boolean containsValue(Object value) {
        Object v = maskNull(value);
        final var vals = Enum2ObjectMap.this.vals;
        final int length = vals.length;
        for (int i = 0; i < length; i++) {
            if (v.equals(vals[i])) return true;
        }
        return false;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void clear() {
        if (size == 0) return;
        Arrays.fill(vals, null);
        size = 0;
    }

    @Override
    public void forEach(BiConsumer<? super K, ? super V> action) {
        final var vals = Enum2ObjectMap.this.vals;
        final int length = vals.length;
        for (int i = 0; i < length; i++) {
            if (vals[i] != null) action.accept(keys[i], unmaskNull(vals[i]));
        }
    }

    @Override
    public FastEntrySet<K, V> reference2ReferenceEntrySet() {
        return entrySet;
    }

    @Override
    public ReferenceSet<K> keySet() {
        return keySet;
    }

    @Override
    public ReferenceCollection<V> values() {
        return values;
    }

    @Override
    public V putIfAbsent(K key, V value) {
        int i = key.ordinal();
        Object old = vals[i];
        if (old != null) return unmaskNull(old);
        vals[i] = maskNull(value);
        size++;
        return defRetValue;
    }

    @Override
    public boolean remove(Object key, Object value) {
        if (!isValidKey(key)) return false;
        int i = ((Enum<?>) key).ordinal();
        Object v = vals[i];
        if (v == null || !Objects.equals(unmaskNull(v), value)) return false;
        vals[i] = null;
        size--;
        return true;
    }

    @Override
    public boolean replace(K key, V oldValue, V newValue) {
        int i = key.ordinal();
        Object v = vals[i];
        if (v == null || !Objects.equals(unmaskNull(v), oldValue)) return false;
        vals[i] = maskNull(newValue);
        return true;
    }

    @Override
    public V replace(K key, V value) {
        int i = key.ordinal();
        Object old = vals[i];
        if (old == null) return defRetValue;
        vals[i] = maskNull(value);
        return unmaskNull(old);
    }

    @Override
    public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
        int i = key.ordinal();
        Object old = vals[i];
        V present = unmaskNull(old);

        if (present != null) return present;
        V newValue = mappingFunction.apply(key);
        if (newValue != null) {
            vals[i] = maskNull(newValue);
            if (old == null) size++;
        }
        return newValue;
    }

    @Override
    public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        int i = key.ordinal();
        V oldValue = unmaskNull(vals[i]);

        if (oldValue == null) return defRetValue;
        V newValue = remappingFunction.apply(key, oldValue);
        if (newValue == null) {
            vals[i] = null;
            size--;
            return defRetValue;
        }
        vals[i] = maskNull(newValue);
        return newValue;
    }

    @Override
    public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        int i = key.ordinal();
        Object old = vals[i];
        V newValue = remappingFunction.apply(key, unmaskNull(old));
        if (newValue == null) {
            if (old != null) {
                vals[i] = null;
                size--;
            }
            return defRetValue;
        }
        vals[i] = maskNull(newValue);
        if (old == null) size++;
        return newValue;
    }

    @Override
    public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
        Objects.requireNonNull(value);
        int i = key.ordinal();
        Object old = vals[i];
        V oldValue = unmaskNull(old);
        V newValue = oldValue == null ? value : remappingFunction.apply(oldValue, value);
        if (newValue == null) {
            if (old != null) {
                vals[i] = null;
                size--;
            }
            return defRetValue;
        }
        vals[i] = maskNull(newValue);
        if (old == null) size++;
        return newValue;
    }

    /** 同类型容器可直接沿值数组遍历。 */
    @Override
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof Map<?, ?> m)) return false;
        if (m.size() != size) return false;
        if (o instanceof Enum2ObjectMap<?, ?> other && other.keyType == keyType) {
            final Object[] a = this.vals;
            final Object[] b = other.vals;
            for (int i = 0, n = a.length; i < n; i++) {
                Object av = a[i];
                Object bv = b[i];
                if (av == bv) continue;
                if (av == null || bv == null) return false;
                if (!Objects.equals(unmaskNull(av), unmaskNull(bv))) return false;
            }
            return true;
        }
        final var vals = this.vals;
        final var keys = this.keys;
        for (int i = 0, n = vals.length; i < n; i++) {
            Object v = vals[i];
            if (v != null) {
                V uv = unmaskNull(v);
                if (uv == null) {

                    if (!m.containsKey(keys[i]) || m.get(keys[i]) != null) return false;
                } else {
                    if (!uv.equals(m.get(keys[i]))) return false;
                }
            }
        }
        return true;
    }

    /** 迭代复用当前条目，下一次移动时内容会更新。 */
    @Override
    public int hashCode() {
        int h = 0;
        final var vals = this.vals;
        final var keys = this.keys;
        for (int i = 0, n = vals.length; i < n; i++) {
            Object v = vals[i];
            if (v != null) h += keys[i].hashCode() ^ Objects.hashCode(unmaskNull(v));
        }
        return h;
    }

    /** 同类型容器可直接沿值数组遍历。 */
    @Override
    @SuppressWarnings("unchecked")
    public void putAll(Map<? extends K, ? extends V> m) {
        if (m instanceof Enum2ObjectMap<?, ?> other && other.keyType == keyType) {
            if (other.size == 0) return;
            final Object[] src = other.vals;
            final Object[] dst = this.vals;
            int sz = this.size;
            for (int i = 0, n = dst.length; i < n; i++) {
                Object v = src[i];
                if (v != null) {
                    if (dst[i] == null) sz++;
                    dst[i] = v;
                }
            }
            this.size = sz;
            return;
        }
        super.putAll(m);
    }

    private boolean isValidKey(Object key) {
        if (key == null) return false;
        Class<?> keyClass = key.getClass();
        return keyClass == keyType || keyClass.getSuperclass() == keyType;
    }

    private static Object maskNull(Object value) {
        return value == null ? NULL : value;
    }

    @SuppressWarnings("unchecked")
    private V unmaskNull(Object value) {
        return (V) (value == NULL ? null : value);
    }

    private final class EntrySet extends AbstractObjectSet<Reference2ReferenceMap.Entry<K, V>>
                                 implements Reference2ReferenceMap.FastEntrySet<K, V> {

        @Override
        public ObjectIterator<Reference2ReferenceMap.Entry<K, V>> iterator() {
            return new EntryIterator();
        }

        @Override
        public ObjectIterator<Reference2ReferenceMap.Entry<K, V>> fastIterator() {
            return new EntryIterator();
        }

        /** 迭代复用当前条目，下一次移动时内容会更新。 */
        @Override
        public void fastForEach(Consumer<? super Reference2ReferenceMap.Entry<K, V>> consumer) {
            Entry entry = new Entry();
            final var vals = Enum2ObjectMap.this.vals;
            final int length = vals.length;
            for (int i = 0; i < length; i++) {
                if (vals[i] != null) {
                    entry.index = i;
                    consumer.accept(entry);
                }
            }
        }

        @Override
        public int size() {
            return size;
        }

        @Override
        public void clear() {
            Enum2ObjectMap.this.clear();
        }

        @Override
        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry<?, ?> e)) return false;
            if (!isValidKey(e.getKey())) return false;
            int i = ((Enum<?>) e.getKey()).ordinal();
            return vals[i] != null && Objects.equals(unmaskNull(vals[i]), e.getValue());
        }

        @Override
        public boolean remove(Object o) {
            if (!contains(o)) return false;
            Enum2ObjectMap.this.remove(((Map.Entry<?, ?>) o).getKey());
            return true;
        }
    }

    private final class Entry implements Reference2ReferenceMap.Entry<K, V> {

        private int index = -1;

        @Override
        public K getKey() {
            return keys[index];
        }

        @Override
        public V getValue() {
            return unmaskNull(vals[index]);
        }

        @Override
        public V setValue(V value) {
            V old = getValue();
            vals[index] = maskNull(value);
            return old;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Map.Entry<?, ?> e)) return false;
            return e.getKey() == keys[index] && Objects.equals(getValue(), e.getValue());
        }

        @Override
        public int hashCode() {
            return keys[index].hashCode() ^ Objects.hashCode(getValue());
        }

        @Override
        public String toString() {
            return keys[index] + "=" + getValue();
        }
    }

    private abstract class IndexIterator {

        int cursor;
        int current = -1;

        public boolean hasNext() {
            final var vals = Enum2ObjectMap.this.vals;
            final int length = vals.length;
            while (cursor < length && vals[cursor] == null) {
                cursor++;
            }
            return cursor < length;
        }

        int advance() {
            if (!hasNext()) throw new NoSuchElementException();
            return current = cursor++;
        }

        public void remove() {
            if (current < 0) throw new IllegalStateException();
            if (vals[current] != null) {
                vals[current] = null;
                size--;
            }
            current = -1;
        }
    }

    private final class EntryIterator extends IndexIterator implements ObjectIterator<Reference2ReferenceMap.Entry<K, V>> {

        private final Entry entry = new Entry();

        @Override
        public Reference2ReferenceMap.Entry<K, V> next() {
            entry.index = advance();
            return entry;
        }
    }

    private final class KeyIterator extends IndexIterator implements ObjectIterator<K> {

        @Override
        public K next() {
            return keys[advance()];
        }
    }

    private final class ValueIterator extends IndexIterator implements ObjectIterator<V> {

        @Override
        public V next() {
            return unmaskNull(vals[advance()]);
        }
    }

    private final class KeySet extends AbstractReferenceSet<K> {

        @Override
        public ObjectIterator<K> iterator() {
            return new KeyIterator();
        }

        @Override
        public int size() {
            return size;
        }

        @Override
        public void clear() {
            Enum2ObjectMap.this.clear();
        }

        @Override
        public boolean contains(Object o) {
            return containsKey(o);
        }

        @Override
        public boolean remove(Object o) {
            if (!containsKey(o)) return false;
            Enum2ObjectMap.this.remove(o);
            return true;
        }
    }

    private final class Values extends AbstractReferenceCollection<V> {

        @Override
        public ObjectIterator<V> iterator() {
            return new ValueIterator();
        }

        @Override
        public boolean contains(Object o) {
            return containsValue(o);
        }

        @Override
        public int size() {
            return size;
        }

        @Override
        public void clear() {
            Enum2ObjectMap.this.clear();
        }
    }
}
